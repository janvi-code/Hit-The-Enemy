import pygame
import random
import os
#initializing pygame
pygame.init()
pygame.mixer.init()

#colors
white=(255,255,255)
black=(0,0,0)

green=(34,177,76)
light_green=(0,255,0)

light_red=(255,0,0)
red=(200,0,0)

light_yellow=(255,255,0)
yellow=(200,200,0)

clock = pygame.time.Clock()

#variables
screen_width = 800
screen_height = 550
gamewindow=pygame.display.set_mode((screen_width,screen_height))
tank_width=60
tank_height=20
#setting image
img=pygame.image.load("tankk.jpg")
img = pygame.transform.scale(img, (screen_width, screen_height)).convert_alpha()

#setting title
pygame.display.set_caption("Tanks")

#setting textfont
largefont=pygame.font.SysFont("comicsansms",70)
medfont=pygame.font.SysFont("comicsansms",35)
smallfont=pygame.font.SysFont(None,30)


#direction="right"
def draw_tank(x,y,q,w,tur_pos):

    position_tank=[(x-40,y-2),
                   (x-38,y-6),
                   (x-36,y-10),
                   (x-34,y-14),
                   (x-32,y-18),
                   (x-30,y-22),
                   (x-28,y-26),
                   (x-26,y-30),
                   (x-24,y-34),
                   (x-22,y-38)]

    pygame.draw.circle(gamewindow,black,(x,y),18)
    pygame.draw.rect(gamewindow,black,(x-30,y,q,w))

    pygame.draw.line(gamewindow, black, (x,y),  position_tank[tur_pos], 5)


    pygame.draw.circle(gamewindow, black, (x-25, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x-20, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x-15, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x-10, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x-5,  y+20), 5)
    pygame.draw.circle(gamewindow, black, (x,    y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+5,  y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+10, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+15, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+20, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+25, y+20), 5)

    return position_tank[tur_pos]


def draw_enemy_tank(x,y,q,w,tur_pos):

    position_tank=[(x+40,y-2),
                   (x+38,y-6),
                   (x+36,y-10),
                   (x+34,y-14),
                   (x+32,y-18),
                   (x+30,y-22),
                   (x+28,y-26),
                   (x+26,y-30),
                   (x+24,y-34),
                   (x+22,y-38)]

    pygame.draw.circle(gamewindow,black,(x,y),18)
    pygame.draw.rect(gamewindow,black,(x-30,y,q,w))

    pygame.draw.line(gamewindow, black, (x,y),  position_tank[tur_pos], 5)


    pygame.draw.circle(gamewindow, black, (x-25, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x-20, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x-15, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x-10, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x-5,  y+20), 5)
    pygame.draw.circle(gamewindow, black, (x,    y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+5,  y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+10, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+15, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+20, y+20), 5)
    pygame.draw.circle(gamewindow, black, (x+25, y+20), 5)

    return position_tank[tur_pos]

def game_control():
    intro=True
    while intro:
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    pygame.quit()
                    quit()

            gamewindow.fill(white)
            text_screen("Controls!!", green, 180, 40, "large")
            text_screen("Fire:SPACEBAR!!", black, 200, 190, "med")
            text_screen("Move:Left and Right arrow keys!!", red, 80, 250, "med")
            text_screen("Pause:P!!", black, 220, 300, "med")

            button("Play", 100, 400, 100, 50, light_green, green, action="play")
            button("Quit", 550, 400, 100, 50, light_red, red, action="quit")

            pygame.display.update()
            clock.tick(30)

def button(text,x,y,x1,y1,active_color,inactive_color,action=None):
    cur = pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    if x+x1>cur[0]>x and y+y1>cur[1]>y:
        pygame.draw.rect(gamewindow,active_color,(x,y,x1,y1))
        if click[0]==1 and action!=None:
            if action=="quit":
                pygame.quit()
                quit()
            if action=="control":
                game_control()
            if action=="play":
                gameloop()
    else:
        pygame.draw.rect(gamewindow, inactive_color, (x, y, x1, y1))
    text_to_button(text,black,x,y,x1,y1,"med")

def text_to_button(text,color,x,y,width,height,size):
    if size=="med":
        screen_text=medfont.render(text,True,color,size)
    if size == "small":
            screen_text = smallfont.render(text, True, color, size)
    if size=="large":
        screen_text=largefont.render(text,True,color,size)
    gamewindow.blit(screen_text, [x, y])

def paused():
    pause=True
    while pause:
        gamewindow.fill(white)
        pygame.draw.line(gamewindow, red, (10, 30), (690, 30), 5)
        pygame.draw.line(gamewindow, red, (10, 30), (10, 490), 5)
        pygame.draw.line(gamewindow, red, (690, 30), (690, 490), 5)
        pygame.draw.line(gamewindow, red, (10, 490), (690, 490), 5)
        text_screen("Press C to Continue or Q to Quit!!", black, 30, 180, "med")

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                   pause=False
                if event.key == pygame.K_q:
                    pygame.quit()
                    quit()
                if event.key == pygame.K_p:
                    paused()
        clock.tick(5)
        pygame.display.update()

def explosion(x,y,size=50):
    explode=True
    while explode:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        startpoint=x,y
        color_choices=[red,green,light_green,light_red,light_yellow,yellow,black]
        magnitude=1
        while magnitude<size:
            exploding_x=x+random.randrange(-1*magnitude,magnitude)
            exploding_y = y + random.randrange(-1 * magnitude, magnitude)

            pygame.draw.circle(gamewindow,color_choices[random.randint(0,4)],(exploding_x,exploding_y),random.randrange(1,5))
            magnitude+=1

            pygame.display.update()
            clock.tick(100)
        explode=False

def fired2(xy,tankx,tanky,tankpos,gun_pow,xlocation,height,enemy_tank_x,enemy_tank_y):
    pygame.mixer.music.load("janvi.mp3")
    pygame.mixer.music.play()
    fire=True
    starting_shell=list(xy)
    Damage=0
    while fire:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
               pygame.quit()
               quit()

        pygame.draw.circle(gamewindow,green,(starting_shell[0],starting_shell[1]),5)
        starting_shell[0]-=(12-tankpos)*2

        starting_shell[1]+=int(((starting_shell[0]-xy[0])*0.02/(gun_pow/50))**2-(tankpos+tankpos/(12-tankpos)))
        if starting_shell[1]>tanky:
            hit_x=int((starting_shell[0]*tanky)/starting_shell[1])
            hit_y=int(tanky)
            if enemy_tank_x+10>hit_x>enemy_tank_x-10:
                Damage=25
            if enemy_tank_x + 15 > hit_x > enemy_tank_x - 15:
                Damage = 18
            if enemy_tank_x + 25 > hit_x > enemy_tank_x - 25:
                Damage = 10
            if enemy_tank_x + 35 > hit_x > enemy_tank_x - 35:
                Damage = 5
            explosion(hit_x,hit_y)
            fire = False


        check_x1=starting_shell[0]<=xlocation+50
        check_x2=starting_shell[0]>=xlocation

        check_y1 = starting_shell[1] <=screen_height
        check_y2 = starting_shell[1] >= screen_height-height

        if check_x1 and check_x2 and check_y1 and check_y2:
            hit_x = int(starting_shell[0])
            hit_y = int(starting_shell[1])
            explosion(hit_x, hit_y)
            fire = False

        pygame.display.update()
        clock.tick(60)
    return Damage
def enemy_fired2(xy,tankx,tanky,tankpos,gun_pow,xlocation,height,p_tank_x,p_tank_y):
    pygame.mixer.music.load("janvi.mp3")
    pygame.mixer.music.play()
    cureent_power=1
    power_found=False
    damage=0
    while not power_found:
        cureent_power+=1
        if cureent_power>100:
            power_found=True
        cureent_power+=1
        fire = True
        starting_shell = list(xy)

    while fire:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
               pygame.quit()
               quit()

        #pygame.draw.circle(gamewindow,green,(starting_shell[0],starting_shell[1]),5)
        starting_shell[0]+=(12-tankpos)*2
        starting_shell[1]+=int(((starting_shell[0]-xy[0])*0.02/(gun_pow/50))**2-(tankpos+tankpos/(12-tankpos)))

        if starting_shell[1]>tanky:
            hit_x=int((starting_shell[0]*tanky)/starting_shell[1])
            hit_y=int(tanky)

            if p_tank_x+15>hit_x>p_tank_x-15:
                power_found=True
            fire = False


        check_x1=starting_shell[0]<=xlocation+50
        check_x2=starting_shell[0]>xlocation

        check_y1 = starting_shell[1] <=screen_height
        check_y2 = starting_shell[1] > screen_height-height

        if check_x1 and check_x2 and check_y1 and check_y2:
            hit_x = int(starting_shell[0])
            hit_y = int(starting_shell[1])
            explosion(hit_x, hit_y)
            fire = False

    fire=True
    starting_shell = list(xy)
    while fire:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        pygame.draw.circle(gamewindow, green, (starting_shell[0], starting_shell[1]), 5)
        starting_shell[0] += (12 - tankpos) * 2


        gun_power=random.randrange(int(cureent_power*0.90),int(cureent_power*1.10))

        starting_shell[1] += int( ((starting_shell[0] - xy[0]) * 0.025 / (gun_power / 50)) ** 2 - (tankpos + tankpos / (12 - tankpos)))
        if starting_shell[1] > tanky:
            hit_x = int((starting_shell[0] * tanky) / starting_shell[1])
            hit_y = int(tanky)
            if p_tank_x+ 10 > hit_x > p_tank_x - 10:
                damage = 25
            if p_tank_x + 15 > hit_x > p_tank_x - 15:
                damage = 18
            if p_tank_x + 25 > hit_x > p_tank_x - 25:
                damage = 10
            if p_tank_x + 35 > hit_x > p_tank_x - 35:
                damage = 5
            explosion(hit_x, hit_y)
            fire = False

        check_x1 = starting_shell[0] <= xlocation + 50
        check_x2 = starting_shell[0] >= xlocation

        check_y1 = starting_shell[1] <= screen_height
        check_y2 = starting_shell[1] >= screen_height-height

        if check_x1 and check_x2 and check_y1 and check_y2:
            hit_x = int(starting_shell[0])
            hit_y = int(starting_shell[1])
            explosion(hit_x, hit_y)
            fire = False
        pygame.display.update()
        clock.tick(60)
    return damage
def text_screen(text,color,x,y,size):
    if size=="small":
        screen_text=smallfont.render(text,True,color,size)
    if size=="med":
        screen_text=medfont.render(text,True,color,size)
    if size=="large":
        screen_text=largefont.render(text,True,color,size)
    gamewindow.blit(screen_text,[x,y])

def welcomeloop():
    exit_game=False
    while not exit_game:
        gamewindow.fill(white)
        gamewindow.blit(img, (0, 0))
        text_screen("Welcome to tanks!!",black,80,30,"large")


        button("Play",100, 400, 100, 50,light_green,green,action="play")
        button("Control", 300, 400, 150, 50,light_yellow, yellow,action="control")
        button("Quit" ,550, 400, 100, 50, light_red, red,action="quit")
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit_game = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    gameloop()
                if event.key == pygame.K_q:
                    pygame.quit()
                    quit()
                if event.key == pygame.K_p:
                    paused()
        pygame.display.update()

def barrier(xlocation,height):

    pygame.draw.rect(gamewindow,light_red,[xlocation,560-height,50,height])


def health(player_health,enemy_health):
    if player_health>75:
        player_color=green
    elif player_health>50:
        player_color=yellow
    else:
        player_color=red

    if enemy_health > 75:
       enemy_color = green
    elif enemy_health > 50:
       enemy_color = yellow
    else:
       enemy_color = red

    pygame.draw.rect(gamewindow, enemy_color,[30,20,enemy_health,30])
    pygame.draw.rect(gamewindow, player_color, [650, 20, player_health, 30])


def gameloop():
    global direction
    exit_game = False
    game_over = False
    tank_x=710
    tank_y=480

    enemy_tank_x = 80
    enemy_tank_y = 480

    tank_move=0
    current_pos=0
    change_pos=0
    score=0
    fps=30

    power=50
    power_change=0

    player_health=100
    enemy_health=100

    xlocation=(screen_width/2)+random.randrange(-0.1*screen_width,0.1*screen_width)
    height=random.randrange(screen_height*0.1,screen_height*0.6)

    while not exit_game:

        if game_over:
            gamewindow.fill(white)
            text_screen("Game Over", red, 180, 100,"large")
            text_screen("Press R to Replay or Q to Quit!!", black,30,180,"med")
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit_game = True
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        welcomeloop()
                    if event.key == pygame.K_q:
                        exit_game=True

        else:
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    exit_game=True
                elif event.type==pygame.KEYDOWN:
                    if event.key==pygame.K_RIGHT:
                        tank_move=5
                    if event.key==pygame.K_LEFT:
                        tank_move=-5

                    if event.key==pygame.K_UP:
                        change_pos=1

                    if event.key==pygame.K_DOWN:
                       change_pos=-1

                    if event.key==pygame.K_q:
                        pygame.quit()
                        quit()

                    if event.key == pygame.K_p:
                        paused()

                    if event.key == pygame.K_a:
                        power_change=-1

                    if event.key==pygame.K_d:
                        power_change=1

                    if event.key==pygame.K_SPACE:

                        damage=fired2(gun, tank_x, tank_y, current_pos, power,xlocation,height,enemy_tank_x,enemy_tank_y)
                        enemy_health -= damage


                        possibleMovement=['f','r']
                        move_index=random.randrange(0,2)

                        for x in range(random.randrange(0,10)):
                            if screen_width*0.3>enemy_tank_x>screen_width*0.03:
                                if possibleMovement[move_index]=='f':
                                    enemy_tank_x+=5
                                elif possibleMovement[move_index]=='r':
                                    enemy_tank_x-=5

                                gamewindow.fill(white)
                                health(player_health, enemy_health)
                                gun = draw_tank(tank_x, tank_y, tank_width, tank_height, current_pos)
                                enemy_gun = draw_enemy_tank(enemy_tank_x, enemy_tank_y, tank_width, tank_height,
                                                            current_pos)
                                power = power + power_change

                                current_pos = current_pos + change_pos
                                text_screen("Power: " + str(power) + "%", black, 310, 10, "med")



                                barrier(xlocation, height)
                                pygame.draw.rect(gamewindow, green, [0, screen_height - 31, screen_width, 31], 31)
                                pygame.display.update()
                                clock.tick(60)

                        damage=enemy_fired2(enemy_gun, enemy_tank_x, enemy_tank_y, current_pos, power, xlocation, height,tank_x,tank_y)
                        player_health=player_health-damage
                elif event.type==pygame.KEYUP:
                    if event.key==pygame.K_RIGHT or event.key==pygame.K_LEFT:
                        tank_move=0
                    if event.key==pygame.K_UP or event.key==pygame.K_DOWN:
                        change_pos=0
                    if event.key==pygame.K_a or event.key==pygame.K_d:
                        power_change=0

            tank_x+=tank_move
            gamewindow.fill(white)
            health(player_health,enemy_health)
            gun = draw_tank(tank_x, tank_y, tank_width, tank_height, current_pos)
            enemy_gun=draw_enemy_tank(enemy_tank_x,enemy_tank_y,tank_width,tank_height,current_pos)
            power=power+power_change

            if power>100:
                power=100
            elif power<1:
                power=1

            current_pos=current_pos+change_pos
            text_screen("Power: " + str(power) + "%",black,310,10,"med")

            if current_pos>9 :
                current_pos=9
            elif current_pos<0:
                current_pos=0

            if tank_x-(tank_width/2)<xlocation+50:
                tank_x=tank_x+5


            barrier(xlocation,height)
            pygame.draw.rect(gamewindow,green,[0,screen_height-31,screen_width,31],31)
            pygame.display.update()
            if player_health<1:
                game_o()
            elif enemy_health<1:
                game_win()
            clock.tick(fps)
    pygame.quit()
    quit()
def game_o():
    k=True

    while k:
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    pygame.quit()
                    quit()


            gamewindow.fill(white)
            text_screen("Game Over",red,200,100,"large")
            text_screen("You Died",black,300,200,"med")

            button("Play", 100, 400, 100, 50, light_green, green, action="play")
            button("Control", 300, 400, 150, 50, light_yellow, yellow, action="control")
            button("Quit", 550, 400, 100, 50, light_red, red, action="quit")

            pygame.display.update()
            clock.tick(60)
def game_win():
    game_win=True

    while game_win:
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    pygame.quit()
                    quit()


            gamewindow.fill(white)
            text_screen("You Win",red,200,100,"large")
            text_screen("Congratulations",black,200,200,"med")

            button("Play", 100, 400, 100, 50, light_green, green, action="play")
            button("Control", 300, 400, 150, 50, light_yellow, yellow, action="control")
            button("Quit", 550, 400, 100, 50, light_red, red, action="quit")

            pygame.display.update()
            clock.tick(60)

welcomeloop()